package CLI_GUI_Classes; /**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 23, 2026
 **/

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Tests the functionality of the FileImporter class to verify that
 * Soul Mission Records can be successfully imported from an external
 * text file into the RecordManager. Also tests how the importer handles
 * invalid file paths and unsuccessful import attempts. Uses JUnit 5
 * annotations and assertions to verify expected application behavior.
 */
class FileImporterTest {

    RecordManager manager;
    InputValidator validator;
    FileImporter importer;

    /**
     * Initializes the objects required for the FileImporter tests.
     * Creates a new RecordManager, InputValidator, and FileImporter
     * before each test to provide a fresh testing environment.
     */
    @BeforeEach
    void setUp() {
        // Create the objects needed for testing.
        manager = new RecordManager();
        validator = new InputValidator();
        importer = new FileImporter(validator);
    }

    /**
     * Tests whether the FileImporter successfully imports records
     * from a valid text file into the RecordManager. Verifies that
     * the expected number of records is stored and that the imported
     * record can be located using its record ID.
     *
     * @throws AssertionError if the expected record count or imported
     * record does not match the expected results
     */
    @Test
    @DisplayName("Import Records Test")
    void importRecordsTest() {
        // Import records from the text file.
        importer.importRecords("testRecords.txt", manager);

        // Verify that the record was imported.
        assertEquals(1, manager.getRecordCount(), "Error: The record was not imported.");

        // Verify that the imported record can be found.
        assertNotNull(manager.findById(123456), "Error: The imported record could not be found.");

        // Test success message.
        System.out.println("Success: The record was imported!");
    }
    /**
     * Tests the FileImporter response when attempting to import a
     * text file that does not exist. Verifies that the unsuccessful
     * import attempt does not add records to the RecordManager.
     *
     * @throws AssertionError if the record count does not match
     * the expected result after the unsuccessful import attempt
     */
    @Test
    @DisplayName("Negative Test: File Import")
    void fileImportNegativeTest() {
        // Attempt to open a file that does not exist.
        importer.importRecords("missingFile.txt", manager);

        // Verify that no records were imported.
        assertEquals(1, manager.getRecordCount(), "Error: No records have been imported," +
                " as the file does not exist.");

        System.out.println("Success: The missing file was handled imported!");
    }
}