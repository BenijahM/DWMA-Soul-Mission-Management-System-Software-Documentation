package CLI_GUI_Classes; /**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 29, 2026
 */

import javax.swing.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Color;
/**
 * Represents the main graphical user interface for the DWMA Soul Mission
 * Management System. Provides the primary application window for displaying
 * and managing SoulMissionRecord objects through a JTable.
 *
 * Allows users to add, update, delete, search, and import records, as well
 * as calculate Death Scythe qualification progress. Coordinates interactions
 * between the application's RecordManager, InputValidator,
 * ProgressCalculator, and FileImporter classes.
 *
 * Also manages navigation to the application's secondary GUI dialogs
 * and handles user actions through Swing event listeners.
 */
public class MainFrame {
    private JPanel mainPanel;
    private JPanel headerPanel;
    private JPanel contentPanel;
    private JLabel titleLabel;
    private JLabel searchLabel;
    private JTextField searchField;
    private JButton searchButton;
    private JTable recordTable;
    private JScrollPane ScrollPane;
    private JPanel buttonPanel;
    private JButton addButton;
    private JButton updateButton;
    private JButton refreshButton;
    private JButton deleteButton;
    private JButton progressButton;
    private JButton importButton;
    private JButton exitButton;
    private JLabel statusLabel;
    private JLabel emblemLabel;
    private JLabel yellowCircleLabel;
    private JLabel whiteCircleLabel;
    private JLabel blueCircleLabel;

    private RecordManager recordManager;
    private InputValidator inputValidator;
    private ProgressCalculator progressCalculator;
    private DefaultTableModel tableModel;
    private FileImporter fileImporter;

    /**
     * Constructs the main GUI interface and initializes the objects required
     * to manage and display soul mission records.
     *
     * Initializes the RecordManager, InputValidator, ProgressCalculator,
     * and FileImporter objects, configures the JTable, and loads the existing
     * database records.
     *
     * Also configures the search field placeholder and registers event listeners
     * for the application's buttons to handle user interactions and navigation
     * between GUI dialogs.
     */
    public MainFrame() {
        // Initialize the classes
        recordManager = new RecordManager();
        inputValidator = new InputValidator();
        progressCalculator = new ProgressCalculator();
        fileImporter = new FileImporter(inputValidator);

        setupTable();
        refreshTable();

        // Set placeholder text for the search field.
        searchField.setText("Enter Record ID or Team Name...");
        searchField.setForeground(Color.GRAY);

        searchField.addFocusListener(new java.awt.event.FocusAdapter() {

            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (searchField.getText().equals("Enter Record ID or Team Name...")) {
                    searchField.setText("");
                    searchField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (searchField.getText().trim().isEmpty()) {
                    searchField.setText("Enter Record ID or Team Name...");
                    searchField.setForeground(Color.GRAY);
                }
            }
        });

        // Opens Add Record window
        addButton.addActionListener(e -> {
            AddRecordDialog dialog = new AddRecordDialog(null, recordManager, inputValidator);
            dialog.setVisible(true);
            refreshTable();
        });

        // Opens Delete Record window.
        deleteButton.addActionListener(e -> {
            DeleteRecordDialog dialog = new DeleteRecordDialog(null, recordManager, inputValidator);
            dialog.setVisible(true);
            refreshTable();
        });

        // Opens Qualification Progress window.
        progressButton.addActionListener(e -> {
            ProgressCalcDialog dialog = new ProgressCalcDialog(null, recordManager, inputValidator,
                    progressCalculator);
            dialog.setVisible(true);
        });

        // Listeners for all of the Buttons.
        searchButton.addActionListener(e -> searchRecords());
        refreshButton.addActionListener(e -> {
            refreshTable();
            searchField.setText("Enter Record ID or Team Name...");
            searchField.setForeground(Color.GRAY);
            statusLabel.setText("All records displayed.");});
        exitButton.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(mainPanel);
            confirmExit(window);});
        importButton.addActionListener(e -> importRecords());
        updateButton.addActionListener(e -> updateSelectedRecord());

    }

    /**
     * Configures the JTable used to display stored SoulMissionRecord objects.
     * Creates the table columns using DefaultTableModel and prevents users
     * from directly editing record information within the table.
     */
    private void setupTable() {

        String[] columns = {
                "Record ID",
                "Team Name",
                "Partner Type",
                "Kishin Souls",
                "Witch Souls",
                "Training Level",
                "Active",
                "Last Mission Date"
        };

        tableModel = new DefaultTableModel(columns, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        recordTable.setModel(tableModel);
    }

    /**
     * Refreshes the JTable to display the current records stored in the database.
     * Removes all existing table rows, retrieves the updated collection of
     * SoulMissionRecord objects from RecordManager, and repopulates the table.
     *
     * Updates the status label with the total number of records displayed.
     */
    private void refreshTable() {
        tableModel.setRowCount(0);

        for (SoulMissionRecord record : recordManager.getAllRecordsList()) {

            Object[] row = {
                    record.getRecordId(),
                    record.getTeamName(),
                    record.getPartnerType(),
                    record.getKishinSoulsCollected(),
                    record.getWitchSoulsCollected(),
                    record.getTrainingLevel(),
                    record.isActiveStatus(),
                    record.getLastMissionDate()
            };

            tableModel.addRow(row);
        }
        statusLabel.setText("Total records displayed: " + tableModel.getRowCount());
    }


    /**
     * Searches for a soul mission record using either its record ID or team name.
     * Validates numeric search input before performing an ID search and uses
     * the RecordManager to locate matching records.
     *
     * Displays an appropriate message if the input is invalid or no matching
     * record is found. When a matching record is located, clears the existing
     * table contents and displays only the matching record.
     */
    private void searchRecords() {

        String searchText = searchField.getText().trim();

        if (searchText.equals("Enter Record ID or Team Name...")) {
            searchText = "";
        }

        if (searchText.isEmpty()) {
            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Please enter a Record ID or Team Name.",
                    "Search Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        SoulMissionRecord record = null;

        // Search by Record ID if the input contains only digits.
        if (searchText.matches("[0-9]+")) {

            try {
                int id = Integer.parseInt(searchText);
                String error = inputValidator.validateRecordId(searchText);

                if (!error.isEmpty()) {
                    JOptionPane.showMessageDialog(
                            mainPanel,
                            error,
                            "Invalid Record ID",
                            JOptionPane.ERROR_MESSAGE
                    );
                    return;
                }

                record = recordManager.findById(id);

            } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(
                        mainPanel,
                        "Invalid Record ID.",
                        "Search Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

        } else {

            record = recordManager.findByTeamName(searchText);
        }

        if (record == null) {

            JOptionPane.showMessageDialog(
                    mainPanel,
                    "No matching record was found.",
                    "Search Results",
                    JOptionPane.INFORMATION_MESSAGE
            );

            refreshTable();
            statusLabel.setText("No matching record found.");
            return;
        }

        // Clear the table and display only the matching record.
        tableModel.setRowCount(0);

        Object[] row = {
                record.getRecordId(),
                record.getTeamName(),
                record.getPartnerType(),
                record.getKishinSoulsCollected(),
                record.getWitchSoulsCollected(),
                record.getTrainingLevel(),
                record.isActiveStatus(),
                record.getLastMissionDate()
        };

        tableModel.addRow(row);

        statusLabel.setText("Record found: " + record.getTeamName());
    }

    /**
     * Opens the ImporterDialog to allow the user to select and import records
     * from a text file into the DWMA Soul Mission Management System.
     *
     * Passes the RecordManager and FileImporter objects to the dialog and
     * refreshes the JTable after the dialog closes to display newly imported
     * records.
     */
    private void importRecords() {

        ImporterDialog dialog = new ImporterDialog(
                null,
                recordManager,
                fileImporter
        );

        dialog.setVisible(true);

        // Refresh the table after the import dialog closes.
        refreshTable();

        statusLabel.setText("Record information refreshed.");
    }

    /**
     * Retrieves the record selected in the JTable and opens the
     * UpdateRecordDialog to allow the user to modify its information.
     *
     * Checks whether a table row is selected and retrieves the corresponding
     * SoulMissionRecord using its record ID. Displays an error message if
     * no record is selected or the selected record cannot be located.
     *
     * Refreshes the JTable after the update dialog closes to display
     * the latest record information.
     */
    private void updateSelectedRecord() {

        // Get the selected row.
        int selectedRow = recordTable.getSelectedRow();

        // Check whether a record was selected.
        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    mainPanel,
                    "Please select a record to update.",
                    "Update Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }
        selectedRow = recordTable.convertRowIndexToModel(selectedRow);

        // Get the record ID from the selected row.
        int recordId = (int) tableModel.getValueAt(selectedRow, 0);

        // Find the corresponding record.
        SoulMissionRecord record = recordManager.findById(recordId);

        if (record == null) {

            JOptionPane.showMessageDialog(
                    mainPanel,
                    "The selected record could not be found.",
                    "Update Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        // Open the Update Record dialog.
        UpdateRecordDialog dialog = new UpdateRecordDialog(
                null,
                recordManager,
                inputValidator,
                record
        );

        dialog.setVisible(true);

        // Refresh the table after the dialog closes.
        refreshTable();

        statusLabel.setText("Record information refreshed.");
    }

    /**
     * Displays a confirmation dialog asking the user whether they want
     * to exit the DWMA Soul Mission Management System.
     *
     * Closes the application window if the user confirms the exit request.
     *
     * @param window the application window to dispose of when the user confirms.
     */
    private void confirmExit(Window window) {

        int choice = JOptionPane.showConfirmDialog(
                mainPanel,
                "Are you sure you want to exit the DWMA Soul Mission Management System?",
                "Confirm Exit",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice == JOptionPane.YES_OPTION) {
            window.dispose();
        }
    }

    /**
     * Serves as the entry point for the graphical application.
     *
     * Uses SwingUtilities.invokeLater() to create and display the main
     * application window on the Event Dispatch Thread. Initializes the
     * JFrame, places the MainFrame panel inside it, configures the window
     * closing behavior, and displays the application.
     *
     * @param args command-line arguments supplied when the application starts.
     */
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("DWMA Soul Mission Management System");
            MainFrame mainFrame = new MainFrame();
            frame.setContentPane(mainFrame.mainPanel);
            frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            frame.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    mainFrame.confirmExit(frame);
                }
            });
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
