package CLI_GUI_Classes; /**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 17, 2026
 */
import java.time.LocalDate;

/**
 * Represents an individual soul mission record in the DWMA Soul Mission
 * Management System. Stores the record ID, team name, partner type,
 * number of kishin and witch souls collected, training level, active
 * status, and last mission date. Provides getter and setter methods
 * to access and modify record information, as well as a toString()
 * method for displaying record details. Serves as the primary data
 * model used by classes such as RecordManager, InputValidator,
 * FileImporter, and ProgressCalculator.
 */
public class SoulMissionRecord {
    private int recordId;
    private String teamName;
    private String partnerType;
    private int kishinSoulsCollected;
    private int witchSoulsCollected;
    private double trainingLevel;
    private boolean activeStatus;
    private LocalDate lastMissionDate;

    /**
     * Constructs a new SoulMissionRecord using the supplied information
     * and initializes all record fields, including team details, collected
     * souls, training level, active status, and last mission date.
     *
     * @param recordId the unique six-digit identifier assigned to the record.
     * @param teamName the name of the meister-weapon team.
     * @param partnerType the type of partner associated with the team,
     *                    such as Weapon, Meister, or Team.
     * @param kishinSoulsCollected the number of kishin-egg souls collected.
     * @param witchSoulsCollected the number of witch souls collected.
     * @param trainingLevel the team's current training level.
     * @param activeStatus indicates whether the team is currently active.
     * @param lastMissionDate the date of the team's most recent mission.
     */
    public SoulMissionRecord(int recordId,String teamName, String partnerType, int kishinSoulsCollected,
                             int witchSoulsCollected, double trainingLevel, boolean activeStatus, LocalDate lastMissionDate){
        this.recordId = recordId;
        this.teamName = teamName;
        this.partnerType = partnerType;
        this.kishinSoulsCollected = kishinSoulsCollected;
        this.witchSoulsCollected = witchSoulsCollected;
        this.trainingLevel = trainingLevel;
        this.activeStatus = activeStatus;
        this.lastMissionDate = lastMissionDate;
    }

    /**
     * Retrieves the unique identifier assigned to the soul mission record.
     * @return the record's ID.
     */
    public int getRecordId() {
        return recordId;
    }

    /**
     * Retrieves the name of the meister-weapon team associated with the record.
     * @return the team's name.
     */
    public String getTeamName() {
        return teamName;
    }

    /**
     * Retrieves the partner type associated with the team.
     * @return the partner type, such as Weapon, Meister, or Team.
     */
    public String getPartnerType() {
        return partnerType;
    }

    /**
     * Retrieves the number of kishin-egg souls collected by the team.
     * @return the number of kishin souls collected.
     */
    public int getKishinSoulsCollected() {
        return kishinSoulsCollected;
    }

    /**
     * Retrieves the number of witch souls collected by the team.
     * @return the number of witch souls collected.
     */
    public int getWitchSoulsCollected() {
        return witchSoulsCollected;
    }

    /**
     * Retrieves the team's current training level.
     * @return the team's training level as a double.
     */
    public double getTrainingLevel() {return trainingLevel;}

    /**
     * Retrieves the team's current active status.
     * @return true if the team is active; otherwise, false.
     */
    public boolean isActiveStatus(){return activeStatus;}

    /**
     * Retrieves the date of the team's most recent mission.
     * @return the team's last mission date as a LocalDate object.
     */
    public LocalDate getLastMissionDate() {
        return lastMissionDate;
    }


    /**
     * Updates the unique identifier assigned to the soul mission record.
     * @param recordId the new record ID.
     */
    public void setRecordId(int recordId) { this.recordId = recordId;}

    /**
     * Updates the name of the meister-weapon team associated with the record.
     * @param teamName the new team name.
     */
    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    /**
     * Updates the partner type associated with the team.
     * @param partnerType the new partner type, such as Weapon, Meister, or Team.
     */
    public void setPartnerType(String partnerType) {
        this.partnerType = partnerType;
    }

    /**
     * Updates the number of kishin-egg souls collected by the team.
     * @param kishinSoulsCollected the new number of kishin souls collected.
     */
    public void setKishinSoulsCollected(int kishinSoulsCollected) {
        this.kishinSoulsCollected = kishinSoulsCollected;
    }

    /**
     * Updates the number of witch souls collected by the team.
     * @param witchSoulsCollected the new number of witch souls collected.
     */
    public void setWitchSoulsCollected(int witchSoulsCollected) {
        this.witchSoulsCollected = witchSoulsCollected;
    }

    /**
     * Updates the team's current training level.
     * @param trainingLevel the new training level.
     */
    public void setTrainingLevel(double trainingLevel) {
        this.trainingLevel = trainingLevel;
    }

    /**
     * Updates the team's active status.
     * @param activeStatus true if the team is active; otherwise, false.
     */
    public void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    /**
     * Updates the date of the team's most recent mission.
     * @param lastMissionDate the new last mission date.
     */
    public void setLastMissionDate(LocalDate lastMissionDate) {
        this.lastMissionDate = lastMissionDate;
    }

    /**
     * Returns a formatted String containing the soul mission record's
     * information. Includes the record ID, team name, partner type,
     * kishin and witch souls collected, training level, active status,
     * and last mission date. Overrides the toString() method from
     * the Object class to provide a readable representation of the record.
     *
     * @return a String containing the formatted details of the record.
     */
    @Override
    public String toString() {
        return "Record ID: " + recordId +
                ", Team Name: " + teamName +
                ", Partner Type: " + partnerType +
                ", Kishin Souls Collected: " + kishinSoulsCollected +
                ", Witch Souls Collected: " + witchSoulsCollected +
                ", Training Level: " + trainingLevel +
                ", Active Status: " + activeStatus +
                ", Last Mission Date: " + lastMissionDate;
    }
}
