package CLI_GUI_Classes; /**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 29, 2026
 */

import javax.swing.*;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
/**
 * Provides a graphical interface for searching for and deleting existing
 * SoulMissionRecord objects from the DWMA Soul Mission Management System.
 *
 * Extends JDialog to display a modal form that allows users to enter
 * a record ID, search for the corresponding record, and review its
 * information before confirming deletion.
 *
 * Uses the InputValidator class to validate the entered record ID
 * and the RecordManager class to retrieve and delete records from
 * the SQLite database.
 *
 * Requires user confirmation before permanently removing a record.
 */
public class DeleteRecordDialog extends JDialog{
    private JPanel deleteRecordPanel;
    private JLabel formTitleLabel;
    private JLabel recordIdLabel;
    private JTextField recordIdTextField;
    private JButton searchButton;
    private JPanel searchButtonPanel;
    private JLabel recordInfoLabel;
    private JTextArea recordInfoTextArea;
    private JPanel buttonPanel;
    private JButton deleteButton;
    private JButton cancelButton;

    private RecordManager recordManager;
    private InputValidator inputValidator;
    private SoulMissionRecord selectedRecord;

    /**
     * Constructs and initializes the Delete Record dialog.
     *
     * Receives the RecordManager and InputValidator objects required to
     * search for and delete existing soul mission records. Configures the
     * dialog as a modal window, initializes the record ID placeholder,
     * makes the record information area non-editable, and initially
     * disables the Delete button.
     *
     * Registers action listeners for the Search, Delete, and Cancel buttons
     * to handle the corresponding user interactions.
     *
     * @param parent the parent JFrame used to position the dialog.
     * @param recordManager the RecordManager responsible for retrieving
     *                      and deleting soul mission records.
     * @param inputValidator the InputValidator used to validate the
     *                       record ID entered by the user.
     */
    public DeleteRecordDialog(
            JFrame parent,
            RecordManager recordManager,
            InputValidator inputValidator) {

        this.recordManager = recordManager;
        this.inputValidator = inputValidator;

        setContentPane(deleteRecordPanel);
        setTitle("Delete Soul Mission Record");
        setModal(true);
        pack();
        setLocationRelativeTo(parent);

        // Configure placeholder text for the Record ID field.
        setPlaceholder(recordIdTextField, "Enter 6-digit Record ID...");

        // Make the record information area non-editable.
        recordInfoTextArea.setEditable(false);

        // Initially disable the Delete button.
        deleteButton.setEnabled(false);

        // Button listeners.
        searchButton.addActionListener(e -> searchRecord());
        deleteButton.addActionListener(e -> deleteRecord());
        cancelButton.addActionListener(e -> dispose());
    }

    /**
     * Configures a JTextField to display instructional placeholder text
     * using a light gray font color.
     *
     * Removes the placeholder when the user selects the text field and
     * restores it when the field loses focus while empty.
     *
     * @param field the JTextField being configured.
     * @param placeholder the instructional text displayed when the field
     *                    does not contain user input.
     */
    private void setPlaceholder(JTextField field, String placeholder) {

        Color placeholderColor = Color.GRAY;
        Color textColor = Color.BLACK;

        field.setForeground(placeholderColor);
        field.setText(placeholder);

        field.addFocusListener(new FocusAdapter() {

            @Override
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(textColor);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (field.getText().trim().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(placeholderColor);
                }
            }
        });
    }

    /**
     * Retrieves and validates the record ID entered by the user and searches
     * for the corresponding SoulMissionRecord using RecordManager.
     *
     * If a matching record is found, stores it in the selectedRecord
     * variable, displays its information in the record information area,
     * and enables the Delete button.
     *
     * If the entered ID is invalid or no matching record is found, displays
     * an appropriate error message and prevents the deletion operation
     * from proceeding.
     */
    private void searchRecord() {

        String idText = recordIdTextField.getText().trim();

        // Prevent placeholder text from being treated as user input.
        if (idText.equals("Enter 6-digit Record ID...")) {
            showError("Please enter a Record ID.");
            return;
        }

        // Validate Record ID.
        String error = inputValidator.validateRecordId(idText);

        if (!error.isEmpty()) {
            showError(error);
            return;
        }

        int id = Integer.parseInt(idText);

        // Search for the record.
        selectedRecord = recordManager.findById(id);

        if (selectedRecord == null) {
            recordInfoTextArea.setText("");
            deleteButton.setEnabled(false);

            showError("No record found with ID " + id + ".");
            return;
        }

        // Display the selected record's information.
        recordInfoTextArea.setText(
                "Record ID: " + selectedRecord.getRecordId() + "\n"
                        + "Team Name: " + selectedRecord.getTeamName() + "\n"
                        + "Partner Type: " + selectedRecord.getPartnerType() + "\n"
                        + "Kishin Souls Collected: "
                        + selectedRecord.getKishinSoulsCollected() + "\n"
                        + "Witch Souls Collected: "
                        + selectedRecord.getWitchSoulsCollected() + "\n"
                        + "Training Level: "
                        + selectedRecord.getTrainingLevel() + "\n"
                        + "Active Status: "
                        + selectedRecord.isActiveStatus() + "\n"
                        + "Last Mission Date: "
                        + selectedRecord.getLastMissionDate()
        );

        // Enable the Delete button.
        deleteButton.setEnabled(true);
    }

    /**
     * Initiates the deletion process for the currently selected
     * SoulMissionRecord.
     *
     * Checks that a record has been selected and displays a confirmation
     * dialog containing the record's information before proceeding.
     *
     * If the user confirms the deletion, calls RecordManager to remove
     * the record from the SQLite database. Displays a success message
     * and closes the dialog when deletion is successful. If deletion
     * fails, displays an appropriate error message.
     *
     * Leaves the record unchanged if the user cancels the confirmation.
     */
    private void deleteRecord() {

        if (selectedRecord == null) {
            showError("Please search for a record first.");
            return;
        }

        // Ask the user to confirm deletion.
        int confirmation = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this record?\n\n"
                        + selectedRecord,
                "Confirm Record Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirmation == JOptionPane.YES_OPTION) {

            int id = selectedRecord.getRecordId();

            if (recordManager.deleteRecord(id)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Soul Mission Record deleted successfully!",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE
                );

                dispose();

            } else {
                showError("The record could not be deleted.");
            }
        }
    }

    /**
     * Displays an error message in a JOptionPane dialog to notify the user
     * when an invalid record ID is entered or an operation cannot be completed.
     *
     * @param message the error message displayed to the user.
     */
    private void showError(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Input Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

