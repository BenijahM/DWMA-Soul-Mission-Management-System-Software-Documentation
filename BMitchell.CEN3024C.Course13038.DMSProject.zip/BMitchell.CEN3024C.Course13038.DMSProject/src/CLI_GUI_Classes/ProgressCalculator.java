package CLI_GUI_Classes; /**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 17, 2026
*/
/**
 * Calculates a meister-and-weapon team's progress toward Death Scythe
 * qualification in the DWMA Soul Mission Management System. Uses the
 * number of kishin-egg souls and witch souls collected to determine
 * qualification progress, the number of additional souls needed, and
 * whether a team has met the qualification requirements. Works with
 * SoulMissionRecord objects to retrieve soul collection information
 * and generate formatted qualification progress reports.
 */
public class ProgressCalculator {

    /**
     * Calculates the team's qualification progress by adding the number
     * of kishin souls and witch souls collected. Limits the kishin soul
     * count to 99 and the witch soul count to 1, producing a maximum
     * total of 100.
     *
     * @param record the SoulMissionRecord containing the team's
     *               soul collection information.
     * @return the total number of souls collected, representing
     *         qualification progress out of 100, or -1.0 if the
     *         supplied record is null.
     */
    public double calculatePercentage (SoulMissionRecord record){
        if (record == null) {
            return -1.0;
        }

        int kishinSouls = Math.min(
                record.getKishinSoulsCollected(), 99);

        int witchSouls = Math.min(
                record.getWitchSoulsCollected(), 1);

        return (kishinSouls + witchSouls);
    }

    /**
     * Calculates the number of additional souls the team needs to collect
     * to meet Death Scythe qualification requirements. Uses the collected
     * kishin and witch soul counts, limiting their values to the required
     * maximums of 99 and 1, respectively.
     *
     * @param record the SoulMissionRecord containing the team's
     *               soul collection information.
     * @return the number of additional souls needed to reach 100,
     *         or -1 if the supplied record is null.
     */
    public int calculateSoulsNeeded(SoulMissionRecord record) {
        if (record == null) {
            return -1;
        }

        int kishinSouls = Math.min(
                record.getKishinSoulsCollected(), 99);

        int witchSouls = Math.min(
                record.getWitchSoulsCollected(), 1);

        return 100 - (kishinSouls + witchSouls);
    }

    /**
     * Determines whether the team has met the Death Scythe qualification
     * requirements by checking whether it has collected at least 99
     * kishin-egg souls and at least 1 witch soul.
     *
     * @param record the SoulMissionRecord containing the team's
     *               soul collection information.
     * @return true if the team has collected at least 99 kishin souls
     *         and 1 witch soul; otherwise, false. Returns false if
     *         the supplied record is null.
     */
    public boolean isQualified(SoulMissionRecord record) {
        if (record == null) {
            return false;
        }

        return record.getKishinSoulsCollected() >= 99
                && record.getWitchSoulsCollected() >= 1;
    }

    /**
     * Generates a formatted Death Scythe qualification progress report
     * for a soul mission record. Includes the record ID, team name,
     * collected kishin and witch souls, qualification progress, remaining
     * souls needed, and current qualification status.
     *
     * @param record the SoulMissionRecord containing the team information
     *               used to generate the progress report.
     * @return a formatted String containing the team's qualification
     *         progress report, or an error message if the supplied
     *         record is null.
     */
    public String createProgressReport(SoulMissionRecord record) {
        if (record == null) {
            return "Error: Cannot create a progress report for a null record.";
        }

        double progress = calculatePercentage(record);
        int soulsNeeded = calculateSoulsNeeded(record);
        boolean qualified = isQualified(record);

        return "===== Death Scythe Qualification Progress =====\n"
                + "Record ID: " + record.getRecordId() + "\n"
                + "Team Name: " + record.getTeamName() + "\n"
                + "Kishin Souls Collected: "
                + record.getKishinSoulsCollected() + " / 99\n"
                + "Witch Souls Collected: "
                + record.getWitchSoulsCollected() + " / 1\n"
                + "Qualification Progress: " + progress + "%\n"
                + "Souls Still Needed: " + soulsNeeded + "\n"
                + "Qualification Status: "
                + (qualified ? "Qualified!" : "Not Yet Qualified")
                + "\n==============================================";
    }

}


