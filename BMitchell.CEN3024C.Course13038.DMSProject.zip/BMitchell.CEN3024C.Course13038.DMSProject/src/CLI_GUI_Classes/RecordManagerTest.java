package CLI_GUI_Classes; /**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 23, 2026
 **/

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;
/**
 * Tests the CRUD (Create, Read, Update, and Delete) operations of the
 * RecordManager class to verify that Soul Mission Records are properly
 * added, retrieved, updated, and deleted from the SQLite database.
 * Also tests how RecordManager handles duplicate record IDs, attempts
 * to delete nonexistent records, and attempts to update nonexistent
 * records. Uses JUnit 5 annotations and assertions to verify expected
 * database behavior.
 */
class RecordManagerTest {
    // Create objects to be tested.
    RecordManager manager;
    SoulMissionRecord record;

    /**
     * Initializes a new RecordManager and creates a sample
     * SoulMissionRecord before each test. Adds the sample record
     * to the manager to provide consistent test data for the
     * CRUD operations.
     */
    @BeforeEach
    void setUp() {
        // Create a new manager before each test.
        manager = new RecordManager();

        // Supply test data to a record object.
        record = new SoulMissionRecord(123456, "Be'Nijah", "Weapon",88,
                0,88.0,true,LocalDate.of(2026,10,23));

        // Adding the test record to the manager, for all test.
        manager.addRecord(record);
    }

    /**
     * Tests whether a new SoulMissionRecord can be successfully
     * added to the database. Verifies that the record count
     * increases and that the newly inserted record can be
     * retrieved using its record ID.
     *
     * @throws AssertionError if the record is not successfully
     * added or the expected database results are not returned
     */
    @Test
    @DisplayName("Add Record Test")
    void addRecordTest() {
        // Creating a new record to add to the manager.
        SoulMissionRecord newRecord = new SoulMissionRecord(654321, "Sugar Plum", "Meister",
                50, 0, 75.0, true,
                LocalDate.of(2026, 10, 20));

        // Add the new record.
        boolean result = manager.addRecord(newRecord);

        //Verify that the record was added successfully.
        assertTrue(result, "Error: The record was not added.");

        //Compares the two values and displays a message if they aren't equal.
        assertEquals(2,manager.getRecordCount(),"Error: The record count should be 2.");

        // Verify that the record can be found by its ID.
        assertNotNull(manager.findById(654321), "Error: The record could not be found.");

        // Test success message.
        System.out.println("Success: The record was added!");
    }
    /**
     * Tests how RecordManager handles an attempt to insert a
     * SoulMissionRecord with a record ID that already exists
     * in the database. Verifies that duplicate records are
     * rejected.
     *
     * @throws AssertionError if the duplicate record is accepted
     * instead of being rejected
     */
    @Test
    @DisplayName("Negative Test: Add Duplicate Record")
    void addDuplicateRecordNegativeTest() {
        // Adding the same record again.
        boolean result = manager.addRecord(record);

        // Incorrect expectation: adding a duplicate should succeed.
        assertTrue(result,
                "Error: The duplicate record was not added.");

        System.out.println("Success: Duplicate record added!");
    }

    /**
     * Tests whether an existing SoulMissionRecord can be
     * successfully deleted from the database. Verifies that
     * the deletion operation succeeds, the record can no
     * longer be retrieved, and the database record count
     * decreases to zero.
     *
     * @throws AssertionError if the record is not deleted
     * or the expected database results are not returned
     */
    @Test
    @DisplayName("Remove Record Test")
    void deleteRecordTest() {
        // Remove the record by ID.
        boolean result = manager.deleteRecord(123456);

        // Verify that the record was removed successfully.
        assertTrue(result, "Error: The record was not removed.");

        // Verify that the record can no longer be found.
        assertNull(manager.findById(123456), "Error: The record still exists.");

        // Verify that the manager is now empty.
        assertEquals(0, manager.getRecordCount(), "Error: The record count should be 0.");

        // Test success message.
        System.out.println("Success: The record was removed!");
    }
    /**
     * Tests how RecordManager handles an attempt to delete
     * a SoulMissionRecord using an ID that does not exist
     * in the database. Verifies that the deletion operation
     * is unsuccessful when no matching record is found.
     *
     * @throws AssertionError if the deletion operation
     * incorrectly reports success
     */
    @Test
    @DisplayName("Negative Test: Delete Nonexistent Record")
    void deleteNonexistentRecordNegativeTest() {
        //Deleting the non-existent record.
        boolean result = manager.deleteRecord(654321);

        // Incorrect expectation: deletion should succeed.
        assertTrue(result,
                "Error: The nonexistent record was not deleted.");

        System.out.println("Success: Nonexistent record deleted!");
    }

    /**
     * Tests whether an existing SoulMissionRecord can be
     * successfully updated in the database. Modifies the
     * team's name, witch soul count, and training level,
     * then retrieves the record to verify that the updated
     * information was saved correctly.
     *
     * @throws AssertionError if the updated record does
     * not contain the expected information
     */
    @Test
    @DisplayName("Update Record Test")
    void updateRecord() {
        // Updating the existing record's information.
        record.setTeamName("Buttercup");
        record.setWitchSoulsCollected(1);
        record.setTrainingLevel(90.0);

        // Update the record manager.
        boolean result = manager.updateRecord(record);

        //Retrieving the updated record.
        SoulMissionRecord updatedRecord = manager.findById(123456);

        // Verify that the changes were saved.
        assertEquals("Buttercup", updatedRecord.getTeamName(), "Error: The team name was not updated.");
        assertEquals(90.0, updatedRecord.getTrainingLevel(), "Error: The training level was not updated.");
        System.out.println("Success: The record was updated!");
    }
    /**
     * Tests how RecordManager handles an attempt to update
     * a SoulMissionRecord whose ID does not exist in the
     * database. Verifies that the update operation is
     * unsuccessful when no matching record is found.
     *
     * @throws AssertionError if the update operation
     * incorrectly reports success
     */
    @Test
    @DisplayName("Negative Test: Update Nonexistent Record")
    void updateNonexistentRecordNegativeTest() {

        SoulMissionRecord newRecord = new SoulMissionRecord(654321, "New Team", "Meister",
                10, 0, 50.0, true,
                LocalDate.of(2026, 10, 20));

        boolean result = manager.updateRecord(newRecord);

        // Incorrect expectation: update should succeed.
        assertTrue(result,
                "Error: The nonexistent record was not updated.");

        System.out.println("Success: Nonexistent record updated!");
    }

    /**
     * Tests whether RecordManager can retrieve and display
     * all stored SoulMissionRecord objects. Verifies that
     * the expected record exists, checks the total database
     * record count, and calls getAllRecords() to display
     * the stored records in the console.
     *
     * @throws AssertionError if the expected record cannot
     * be found or the database record count is incorrect
     */
    @Test
    @DisplayName("Display Records Test")
    void getAllRecordsTest() {
        // Verify that the record exists.
        assertNotNull(manager.findById(123456),
                "Error: The record could not be found.");

        // Verify that the record count is correct.
        assertEquals(1, manager.getRecordCount(),
                "Error: The record count should be 1.");

        // Display all records in the console.
        manager.getAllRecords();

        // Test success message.
        System.out.println("Success: The records were displayed!");
    }
}