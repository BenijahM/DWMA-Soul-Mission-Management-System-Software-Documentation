package CLI_GUI_Classes; /**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 23, 2026
 */

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Tests the functionality of the ProgressCalculator class to verify
 * that Death Scythe qualification progress is calculated correctly
 * based on the number of kishin-egg souls and witch souls collected.
 * Uses JUnit 5 testing annotations and assertions to evaluate the
 * calculator's results using sample SoulMissionRecord objects.
 */
class ProgressCalculatorTest {
    ProgressCalculator calculator;
    SoulMissionRecord record;

    /**
     * Initializes a ProgressCalculator object and creates a sample
     * SoulMissionRecord containing test data. Provides a consistent
     * starting point for each qualification progress test.
     */
    @BeforeEach
    void setUp() {
        calculator = new ProgressCalculator();

        // Adding a new record.
        record = new SoulMissionRecord(123456, "Be'Nijah", "Weapon", 88,
                0, 88.0, true, LocalDate.of(2026, 10, 23));
    }

    /**
     * Tests whether the ProgressCalculator correctly calculates the
     * qualification progress percentage for a team with 88 kishin-egg
     * souls and no witch souls. Verifies that the calculated percentage
     * matches the expected result of 88%.
     *
     * @throws AssertionError if the calculated percentage does not
     * match the expected result
     */
    @Test
    @DisplayName("Calculate Qualification Progress Test")
    void calculateProgressTest() {
        // Calculate the team's progress.
        double result = calculator.calculatePercentage(record);

        // Verify the expected progress.
        assertEquals(88.0, result,
                "Error: Qualification progress should be 88%.");

        System.out.println("Success: Qualification progress calculated!");
    }
    /**
     * Tests the calculator using an intentionally incorrect expected
     * qualification percentage. Demonstrates how a JUnit assertion
     * identifies a result that does not match the expected value.
     *
     * @throws AssertionError if the calculated percentage does not
     * match the intentionally incorrect expected result
     */
    @Test
    @DisplayName("Negative Test: Qualification Progress")
    void incorrectProgressTest() {
        double result = calculator.calculatePercentage(record);

        // Intentionally incorrect expectation.
        assertEquals(100.0, result, "Error: Progress should be 100%.");

        System.out.println("Success: Progress calculated!");
    }
}