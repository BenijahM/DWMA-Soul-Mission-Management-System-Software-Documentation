package CLI_GUI_Classes;
/**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 17, 2026
 */

import DBHelper.SoulMissionRecords;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
/**
 * Manages SoulMissionRecord objects and handles communication with the
 * SQLite database for the DWMA Soul Mission Management System. Provides
 * functionality to add, delete, update, search for, and retrieve records
 * stored in the database. Uses the DBHelper.SoulMissionRecords class to
 * execute database operations and converts database results into
 * SoulMissionRecord objects for use throughout the application.
 * Supports both the command-line and graphical user interfaces by
 * providing methods for displaying and retrieving stored records.
 */
public class RecordManager {

    private SoulMissionRecords database;

    /**
     * Constructs a RecordManager and initializes the SoulMissionRecords
     * database helper used to communicate with the SQLite database.
     */
    public RecordManager() {
        database = new SoulMissionRecords();
    }

    /**
     * Adds a new soul mission record to the SQLite database after checking
     * that the record is not null, its ID is positive and unique, and its
     * last mission date is not null.
     *
     * @param record the SoulMissionRecord object containing the information
     *               to be added to the database.
     * @return true if the record is successfully inserted into the database;
     *         otherwise, false.
     */
    public boolean addRecord(SoulMissionRecord record) {

        if (record == null) {
            return false;
        }

        if (record.getRecordId() <= 0 || containsId(record.getRecordId())) {
            return false;
        }

        if (record.getLastMissionDate() == null) {
            return false;
        }

        return database.insert(
                record.getRecordId(),
                record.getTeamName(),
                record.getPartnerType(),
                record.getKishinSoulsCollected(),
                record.getWitchSoulsCollected(),
                record.getTrainingLevel(),
                record.isActiveStatus() ? 1 : 0,
                record.getLastMissionDate().toString()
        );
    }

    /**
     * Deletes a soul mission record from the SQLite database using its
     * unique record ID.
     *
     * @param recordId the ID of the record to be deleted.
     * @return true if the record is successfully deleted; otherwise, false.
     */
    public boolean deleteRecord(int recordId) {

        return database.delete(
                SoulMissionRecords.recordId,
                String.valueOf(recordId)
        );
    }

    /**
     * Updates the information of an existing soul mission record in the
     * SQLite database. Checks that the record is not null, has
     * a valid last mission date, and has an ID that already exists in
     * the database before applying the changes.
     *
     * @param updatedRecord the SoulMissionRecord object containing the
     *                      updated information for the existing record.
     * @return true if the record is successfully updated; otherwise, false.
     */
    public boolean updateRecord(SoulMissionRecord updatedRecord) {

        if (updatedRecord == null) {
            return false;
        }

        if (updatedRecord.getLastMissionDate() == null) {
            return false;
        }

        if (!containsId(updatedRecord.getRecordId())) {
            return false;
        }

        return database.updateRecord(
                updatedRecord.getRecordId(),
                updatedRecord.getTeamName(),
                updatedRecord.getPartnerType(),
                updatedRecord.getKishinSoulsCollected(),
                updatedRecord.getWitchSoulsCollected(),
                updatedRecord.getTrainingLevel(),
                updatedRecord.isActiveStatus() ? 1 : 0,
                updatedRecord.getLastMissionDate().toString()
        );
    }

    /**
     * Searches the SQLite database for a soul mission record matching
     * the specified record ID. Converts the matching database result
     * into a SoulMissionRecord object.
     *
     * @param recordId the ID of the record being searched for.
     * @return the matching SoulMissionRecord object if found; otherwise,
     *         null if no matching record exists.
     */
    public SoulMissionRecord findById(int recordId) {

        ArrayList<ArrayList<Object>> results = database.select(
                "*",
                SoulMissionRecords.recordId,
                String.valueOf(recordId),
                null,
                null
        );

        if (results.isEmpty()) {
            return null;
        }

        return convertToRecord(results.get(0));
    }

    /**
     * Searches the SQLite database for a soul mission record matching
     * the specified team name. Removes surrounding whitespace before
     * performing the search and converts the matching database result
     * into a SoulMissionRecord object.
     *
     * @param teamName the name of the team being searched for.
     * @return the matching SoulMissionRecord object if found; otherwise,
     *         null if the team name is null, blank, or no matching record
     *         exists.
     */
    public SoulMissionRecord findByTeamName(String teamName) {

        if (teamName == null || teamName.trim().isEmpty()) {
            return null;
        }

        ArrayList<ArrayList<Object>> results = database.select(
                "*",
                SoulMissionRecords.teamName,
                teamName.trim(),
                null,
                null
        );

        if (results.isEmpty()) {
            return null;
        }

        return convertToRecord(results.get(0));
    }

    /**
     * Retrieves all stored soul mission records and displays their
     * information in an organized table in the console. Displays the
     * record ID, team name, partner type, collected souls, training
     * level, active status, and last mission date, along with the
     * total number of records displayed.
     */
    public void getAllRecords() {

        List<SoulMissionRecord> records = getAllRecordsList();

        if (records.isEmpty()) {
            System.out.println("There are currently no records in the system.");
            return;
        }

        String separator =
                "----------------------------------------------------------------------------------------------------------------";

        System.out.println(separator);

        System.out.printf(
                "%-8s %-24s %-16s %14s %12s %10s %8s %-12s%n",
                "ID",
                "Team Name",
                "Partner Type",
                "Kishin Souls",
                "Witch Souls",
                "Training",
                "Active",
                "Last Mission"
        );

        System.out.println(separator);

        for (SoulMissionRecord record : records) {

            System.out.printf(
                    "%-8s %-24s %-15s %14d %12d %10.1f %8s %-12s%n",
                    record.getRecordId(),
                    formatCell(record.getTeamName(), 24),
                    formatCell(record.getPartnerType(), 16),
                    record.getKishinSoulsCollected(),
                    record.getWitchSoulsCollected(),
                    record.getTrainingLevel(),
                    record.isActiveStatus() ? "true" : "false",
                    record.getLastMissionDate()
            );
        }

        System.out.println(separator);
        System.out.println("Total records displayed: " + records.size());
    }

    /**
     * Formats a text value to fit within a specified console table column
     * width. Returns an empty String for null values and truncates text
     * that exceeds the available width by adding an ellipsis.
     *
     * @param value the text value being formatted.
     * @param width the maximum number of characters allowed in the column.
     * @return the formatted text, an empty String if the value is null,
     *         or the truncated text if it exceeds the specified width.
     */
    private String formatCell(String value, int width) {

        if (value == null) {
            return "";
        }

        if (value.length() > width) {
            return value.substring(0, width - 3) + "...";
        }

        return value;
    }

    /**
     * Checks whether a soul mission record with the specified ID exists
     * in the SQLite database by searching for a matching record.
     *
     * @param recordId the ID being checked.
     * @return true if a record with the specified ID exists; otherwise,
     *         false.
     */
    public boolean containsId(int recordId) {
        return findById(recordId) != null;
    }

    /**
     * Retrieves the total number of soul mission records currently
     * stored in the SQLite database.
     *
     * @return the total number of records currently stored in the database.
     */
    public int getRecordCount() {

        ArrayList<ArrayList<Object>> results = database.select(
                SoulMissionRecords.recordId,
                null,
                null,
                null,
                null
        );

        return results.size();
    }

    /**
     * Retrieves all soul mission records from the SQLite database and
     * converts the database results into SoulMissionRecord objects.
     * Returns the records in ascending order by record ID for use
     * throughout the application, including the GUI.
     *
     * @return a List containing all stored SoulMissionRecord objects,
     *         ordered by record ID in ascending order.
     */
    public List<SoulMissionRecord> getAllRecordsList() {

        ArrayList<ArrayList<Object>> results = database.select(
                "*",
                null,
                null,
                SoulMissionRecords.recordId,
                "ASC"
        );

        List<SoulMissionRecord> records = new ArrayList<>();

        for (ArrayList<Object> row : results) {
            records.add(convertToRecord(row));
        }

        return records;
    }

    /**
     * Retrieves all soul mission records from the database by delegating
     * to getAllRecordsList().
     *
     * @return a List containing all stored SoulMissionRecord objects.
     */
    public List<SoulMissionRecord> getRecords() {
        return getAllRecordsList();
    }

    /**
     * Converts a database query result row into a SoulMissionRecord object.
     *
     * @param row an ArrayList containing the eight database column values.
     * @return A SoulMissionRecord object containing the database values.
     */
    private SoulMissionRecord convertToRecord(ArrayList<Object> row) {

        return new SoulMissionRecord(
                ((Number) row.get(0)).intValue(),
                String.valueOf(row.get(1)),
                String.valueOf(row.get(2)),
                ((Number) row.get(3)).intValue(),
                ((Number) row.get(4)).intValue(),
                ((Number) row.get(5)).doubleValue(),
                ((Number) row.get(6)).intValue() == 1,
                LocalDate.parse(String.valueOf(row.get(7)))
        );
    }
}
