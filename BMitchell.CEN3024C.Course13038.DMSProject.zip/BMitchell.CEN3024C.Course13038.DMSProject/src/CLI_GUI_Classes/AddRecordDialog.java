package CLI_GUI_Classes; /**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 29, 2026
 */

import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
/**
 * Provides a graphical form for creating and adding new SoulMissionRecord
 * objects to the DWMA Soul Mission Management System.
 *
 * Extends JDialog to display a modal input form that collects the record ID,
 * team name, partner type, kishin souls, witch souls, training level,
 * active status, and last mission date.
 *
 * Uses the InputValidator class to validate user-entered information
 * and the RecordManager class to check for duplicate record IDs and
 * store successfully validated records in the SQLite database.
 */
public class AddRecordDialog extends JDialog {
    private JPanel addRecordPanel;
    private JLabel formTitleLabel;
    private JLabel recordId;
    private JTextField recordIdTextField;
    private JLabel teamName;
    private JLabel partnerType;
    private JLabel kishinSouls;
    private JLabel witchSouls;
    private JLabel trainingLevel;
    private JLabel activeStatus;
    private JLabel missionDate;
    private JTextField teamNameTextField;
    private JTextField kishinSoulsTextField;
    private JTextField witchSoulsTextField;
    private JTextField trainingLevelTextField;
    private JTextField missionDateTextField;
    private JComboBox partnerTypeComboBox;
    private JComboBox activeStatuscomboBox;
    private JButton cancelButton;
    private JButton saveButton;
    private JPanel buttonPanel;

    private RecordManager recordManager;
    private InputValidator inputValidator;

    /**
     * Constructs and initializes the Add Record dialog.
     *
     * Receives the RecordManager and InputValidator objects required to
     * validate and store new soul mission records. Configures the dialog
     * as a modal window, initializes placeholder text for the input fields,
     * and registers action listeners for the Save and Cancel buttons.
     *
     * @param parent the parent JFrame used to position the dialog.
     * @param recordManager the RecordManager responsible for managing
     *                      and storing soul mission records.
     * @param inputValidator the InputValidator used to validate the
     *                       information entered into the form.
     */
    public AddRecordDialog(JFrame parent, RecordManager recordManager, InputValidator inputValidator) {
        this.recordManager = recordManager;
        this.inputValidator = inputValidator;

        setContentPane(addRecordPanel);
        setTitle("Add New Soul Mission Record");
        setModal(true);
        pack();
        setLocationRelativeTo(parent);

        // Configure placeholder text for the input fields.
        setPlaceholder(recordIdTextField, "Enter 6-digit Record ID...");
        setPlaceholder(teamNameTextField, "Enter team name...");
        setPlaceholder(kishinSoulsTextField, "Enter number (0-99)...");
        setPlaceholder(witchSoulsTextField, "Enter number (0 or 1)...");
        setPlaceholder(trainingLevelTextField, "Enter level (1.0-100.0)...");
        setPlaceholder(missionDateTextField, "YYYY-MM-DD");

        saveButton.addActionListener(e -> saveRecord());
        cancelButton.addActionListener(e -> dispose());
    }

    /**
     * Configures a JTextField to display instructional placeholder text
     * using a light gray font color.
     *
     * Removes the placeholder when the user selects the text field and
     * restores it when the field loses focus while empty.
     *
     * @param field the JTextField being configured.
     * @param placeholder the instructional text displayed when the field
     *                    does not contain user input.
     */
    private void setPlaceholder(JTextField field, String placeholder) {

        Color placeholderColor = Color.GRAY;
        Color textColor = Color.BLACK;

        field.setForeground(placeholderColor);
        field.setText(placeholder);

        field.addFocusListener(new FocusAdapter() {

            @Override
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(textColor);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (field.getText().trim().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(placeholderColor);
                }
            }
        });
    }

    /**
     * Collects, converts, and validates the information entered into the
     * Add Record form before creating a new SoulMissionRecord object.
     *
     * Validates the record ID, checks for duplicate IDs, verifies the team
     * name and partner type, converts and validates the soul counts and
     * training level, checks the active status, and validates the mission date.
     *
     * Creates a new SoulMissionRecord after all individual fields pass
     * validation and performs a final validation of the complete record.
     *
     * If the record passes validation, it is added through RecordManager.
     * Displays a success message and closes the dialog when the record is
     * successfully added. Otherwise, displays an appropriate error message.
     */
    private void saveRecord() {

        // Read information from the text fields
        String idText = recordIdTextField.getText().trim();
        String name = teamNameTextField.getText().trim();
        String partnerType = String.valueOf(partnerTypeComboBox.getSelectedItem());

        String kishinText = kishinSoulsTextField.getText().trim();
        String witchText = witchSoulsTextField.getText().trim();
        String trainingText = trainingLevelTextField.getText().trim();

        String activeText = String.valueOf(activeStatuscomboBox.getSelectedItem());
        String dateText = missionDateTextField.getText().trim();

        // Prevent placeholder text from being treated as user input.
        if (idText.equals("Enter 6-digit Record ID...")
                || name.equals("Enter team name...")
                || kishinText.equals("Enter number (0-99)...")
                || witchText.equals("Enter number (0 or 1)...")
                || trainingText.equals("Enter level (1.0-100.0)...")
                || dateText.equals("YYYY-MM-DD")) {

            showError("Please complete all required fields.");
            return;
        }

        // Validate Record ID
        String error = inputValidator.validateRecordId(idText);
        if (!error.isEmpty()) {
            showError(error);
            return;
        }

        int id = Integer.parseInt(idText);

        // Check for duplicate IDs
        if (recordManager.containsId(id)) {
            showError("That record ID already exists.");
            return;
        }

        // Validate Team Name
        error = inputValidator.validateTeamName(name);
        if (!error.isEmpty()) {
            showError(error);
            return;
        }

        // Validate Partner Type
        error = inputValidator.validatePartnerType(partnerType);
        if (!error.isEmpty()) {
            showError(error);
            return;
        }


        // Convert and validate soul counts
        int kishin;
        int witch;
        try {
            kishin = Integer.parseInt(kishinText);
            witch = Integer.parseInt(witchText);

        } catch (NumberFormatException e) {
            showError("Soul counts must be whole numbers.");
            return;
        }

        error = inputValidator.validateKishinSouls(kishin);
        if (!error.isEmpty()) {
            showError("Kishin souls: " + error);
            return;
        }

        error = inputValidator.validateWitchSouls(witch);
        if (!error.isEmpty()) {
            showError("Witch souls: " + error);
            return;
        }


        // Convert and validate training level
        double training;
        try {
            training = Double.parseDouble(trainingText);

        } catch (NumberFormatException e) {
            showError("Training level must be a number.");
            return;
        }

        error = inputValidator.validateTrainingLevel(training);
        if (!error.isEmpty()) {
            showError(error);
            return;
        }


        // Validate Active Status
        if (!activeText.equalsIgnoreCase("true")
                && !activeText.equalsIgnoreCase("false")) {
            showError("Please select true or false for active status.");
            return;
        }

        boolean active = Boolean.parseBoolean(activeText);

        // Validate Mission Date
        error = inputValidator.validateDate(dateText);
        if (!error.isEmpty()) {
            showError(error);
            return;
        }

        LocalDate missionDate;
        try {
            missionDate = LocalDate.parse(dateText);

        } catch (DateTimeParseException e) {
            showError("Please enter a valid date in yyyy-MM-dd format.");
            return;
        }


        // Create the new record
        SoulMissionRecord record = new SoulMissionRecord(id, name, partnerType, kishin,
                witch, training, active, missionDate);


        // Validate the complete record
        error = inputValidator.validateRecord(record);
        if (!error.isEmpty()) {
            showError(error);
            return;
        }


        // Add record to the ArrayList
        if (recordManager.addRecord(record)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Soul Mission Record added successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
            dispose();
        } else {
            showError("Record could not be added.");
        }
    }

    /**
     * Displays an error message in a JOptionPane dialog to notify the user
     * when entered information is invalid or an operation cannot be completed.
     *
     * @param message the error message displayed to the user.
     */
    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Input Error",
                JOptionPane.ERROR_MESSAGE);
    }
}
