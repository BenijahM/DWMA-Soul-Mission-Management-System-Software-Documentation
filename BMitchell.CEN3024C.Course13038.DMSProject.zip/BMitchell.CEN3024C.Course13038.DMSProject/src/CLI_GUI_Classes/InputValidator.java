package CLI_GUI_Classes;
/**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * October 17, 2026
 */
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
/**
 * Validates user input and soul mission record data for the DWMA Soul
 * Mission Management System. Ensures that record information follows
 * the application's requirements before records are stored or updated.
 * Provides validation methods for record IDs, team names, partner types,
 * soul counts, training levels, mission dates, and complete
 * SoulMissionRecord objects. Works with classes such as ConsoleUI,
 * FileImporter, and RecordManager to maintain valid record information
 * throughout the application.
 */
public class InputValidator {

    /**
     * Validates that a record ID contains exactly six digits and is not
     * equal to zero. Rejects IDs containing letters, spaces, or special
     * characters.
     *
     * @param recordId the record ID being validated.
     * @return an empty String if the ID is valid, or an error message
     *         describing why the ID is invalid.
     */
    public String validateRecordId(String recordId) {
        if (recordId == null) {
            return "Record ID cannot be empty.";
        }

        if (!recordId.matches("[0-9]{6}")) {
            return "Record ID must contain exactly six digits with no spaces or special characters.";
        }

        if (recordId.equals("000000")) {
            return "Record ID must be a positive six-digit number.";
        }

        return "";
    }

    /**
     * Validates that a team name is not null or blank.
     *
     * @param teamName the name of the meister-weapon team being validated.
     * @return an empty String if the team name is valid, or an error
     *         message if the name is null or blank.
     */
    public String validateTeamName(String teamName) {
        if (teamName == null || teamName.isBlank()) {
            return "Team name cannot be blank.";
        }

        return "";
    }

    /**
     * Validates that the partner type matches one of the approved values:
     * Weapon, Meister, or Team. The comparison is case-insensitive.
     *
     * @param partnerType the type of partner associated with the team.
     * @return an empty String if the partner type is valid, or an error
     *         message if it is null, blank, or does not match an approved type.
     */
    public String validatePartnerType(String partnerType) {
        if (partnerType == null || partnerType.isBlank()) {
            return "Partner type cannot be blank.";
        }

        if (!partnerType.equalsIgnoreCase("Weapon")
                && !partnerType.equalsIgnoreCase("Meister")
                && !partnerType.equalsIgnoreCase("Team")) {
            return "Partner type must be Weapon, Meister, or Team.";
        }

        return "";
    }

    /**
     * Validates that the number of souls collected is a non-negative whole number.
     *
     * @param soulCount the number of souls collected.
     * @return an empty String if the soul count is valid, or an error
     *         message if the count is negative.
     */
    public String validateSoulCount(int soulCount) {
        if (soulCount < 0) {
            return "Soul count cannot be negative.";
        }

        return "";
    }

    /**
     * Validates that the number of kishin souls collected is between 0 and 99, inclusive.
     *
     * @param kishinSouls the number of kishin souls collected.
     * @return an empty String if the value is valid, or an error message
     *         if the value is outside the permitted range.
     */
    public String validateKishinSouls(int kishinSouls) {
        if (kishinSouls < 0 || kishinSouls > 99) {
            return "Kishin souls must be between 0 and 99.";
        }

        return "";
    }

    /**
     * Validates that the number of witch souls collected is either 0 or 1.
     *
     * @param witchSouls the number of witch souls collected.
     * @return an empty String if the value is valid, or an error message
     *         if the value is outside the permitted range.
     */
    public String validateWitchSouls(int witchSouls) {
        if (witchSouls < 0 || witchSouls > 1) {
            return "Witch souls must be either 0 or 1.";
        }

        return "";
    }

    /**
     * Validates that the team's training level is a finite numeric value
     * between 1.0 and 100.0, inclusive.
     *
     * @param trainingLevel the team's current training level.
     * @return an empty String if the training level is valid, or an error
     *         message if the value is non-finite or outside the permitted range.
     */
    public String validateTrainingLevel(double trainingLevel) {
        if (!Double.isFinite(trainingLevel)
                || trainingLevel < 1.0
                || trainingLevel > 100.0) {
            return "Training level must be between 1.0 and 100.0.";
        }

        return "";
    }

    /**
     * Validates that a mission date represents a real calendar date
     * in the yyyy-MM-dd format. Uses LocalDate to verify that the
     * supplied date can be parsed successfully.
     *
     * @param date the mission date being validated.
     * @return an empty String if the date is valid, or an error message
     *         if the date is null, blank, incorrectly formatted, or invalid.
     */
    public String validateDate(String date) {
        if (date == null || date.isBlank()) {
            return "Mission date cannot be blank.";
        }

        date = date.trim();

        try {
            LocalDate parsedDate = LocalDate.parse(date);

            if (!parsedDate.toString().equals(date)) {
                return "Date must use yyyy-MM-dd format.";
            }
        } catch (DateTimeParseException e) {
            return "Invalid date. Enter a valid date in yyyy-MM-dd format.";
        }

        return "";
    }

    /**
     * Validates all required fields of a SoulMissionRecord by checking
     * its record ID, team name, partner type, kishin soul count, witch
     * soul count, training level, and last mission date. Returns the
     * first validation error encountered.
     *
     * @param record the SoulMissionRecord object containing the data
     *               to be validated.
     * @return an empty String if all record fields are valid, or the
     *         first error message encountered during validation.
     */
    public String validateRecord(SoulMissionRecord record) {
        if (record == null) {
            return "Record cannot be null.";
        }

        String error;

        error = validateRecordId(
                String.valueOf(record.getRecordId()));
        if (!error.isEmpty()) {
            return error;
        }

        error = validateTeamName(record.getTeamName());
        if (!error.isEmpty()) {
            return error;
        }

        error = validatePartnerType(record.getPartnerType());
        if (!error.isEmpty()) {
            return error;
        }

        error = validateKishinSouls(record.getKishinSoulsCollected());
        if (!error.isEmpty()) {
            return error;
        }

        error = validateWitchSouls(record.getWitchSoulsCollected());
        if (!error.isEmpty()) {
            return error;
        }

        error = validateTrainingLevel(record.getTrainingLevel());
        if (!error.isEmpty()) {
            return error;
        }

        if (record.getLastMissionDate() == null) {
            return "Mission date cannot be null.";
        }

        error = validateDate(record.getLastMissionDate().toString());
        if (!error.isEmpty()) {
            return error;
        }

        return "";
    }
}
