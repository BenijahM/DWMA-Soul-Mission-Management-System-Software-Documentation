/**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * November 7,2026
 */

package DBHelper;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * The JDBC class manages the connection between the DWMA Soul Mission
 * Management System and the SQLite database using Java Database
 * Connectivity (JDBC). It provides methods for establishing database
 * connections, testing connectivity, and retrieving and displaying
 * stored records. This class serves as a database connection utility
 * for other classes in the DBHelper package that interact with the
 * SQLite database.
 */
public class JDBC {

    // Location of the SQLite database.
    private static final String DATABASE_URL =
            "jdbc:sqlite:C:/sqlite/University.db";

    /**
     * Establishes and returns a connection to the SQLite database.
     * Loads the SQLite JDBC driver and uses DriverManager to create
     * a database connection that can be used to execute SQL statements.
     *
     * @return an active Connection to the SQLite database
     * @throws SQLException if the SQLite JDBC driver cannot be found
     *                     or a database connection cannot be established
     */
    public static Connection getConnection() throws SQLException {

        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException(
                    "SQLite JDBC driver could not be found.", e);
        }

        return DriverManager.getConnection(DATABASE_URL);
    }

    /**
     * Tests whether the application can successfully establish a connection
     * to the SQLite database. Displays a success message if the connection
     * is established or an error message if the connection attempt fails.
     * Automatically closes the database connection after testing.
     */
    public static void testConnection() {

        try (Connection connection = getConnection()) {

            System.out.println(
                    "Successfully connected to University.db!");

        } catch (SQLException e) {

            System.out.println("Database connection failed.");
            e.printStackTrace();
        }
    }

    /**
     * Retrieves all records from the SoulMissionRecords database table
     * using an SQL SELECT statement. Uses ResultSetMetaData to determine
     * the number of columns and displays each record's information in
     * the command-line interface. Automatically closes the database
     * connection and SQL resources after the operation is completed.
     */
    public static void displayRecords() {

        String query = "SELECT * FROM SoulMissionRecords";

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(query)) {

            ResultSetMetaData metadata = result.getMetaData();

            int columnCount = metadata.getColumnCount();

            System.out.println(
                    "\nSoulMissionRecords Table Contents:");


            while (result.next()) {

                for (int i = 1; i <= columnCount; i++) {

                    System.out.print(result.getString(i));

                    if (i < columnCount) {
                        System.out.print(" : ");
                    }
                }

                System.out.println();
            }

        } catch (SQLException e) {

            System.out.println("Database query failed.");
            e.printStackTrace();
        }
    }

    /**
     * Serves as the entry point for testing the JDBC database connection
     * and displaying the contents of the SoulMissionRecords table.
     * Calls testConnection() to verify database connectivity and
     * displayRecords() to retrieve and display the stored records.
     *
     * @param args command-line arguments supplied when the application starts
     */
    public static void main(String[] args) {

        // Test the database connection.
        testConnection();

        // Display all records in the database.
        displayRecords();
    }
}
