/**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * November 7,2026
 */
package DBHelper;
import javax.swing.table.DefaultTableModel;
import  java.util.ArrayList;
import java.util.List;
/**
 * Provides a demonstration of database operations for the DWMA Soul
 * Mission Management System. This class uses SoulMissionRecords to
 * retrieve, delete, insert, and display records stored in the SQLite
 * database. It also demonstrates how database query results can be
 * retrieved and displayed using ArrayList collections.
 */
public class UniversityDatabase {
    /**
     * Demonstrates database operations by retrieving, displaying,
     * deleting, and inserting Soul Mission Records. Uses the
     * SoulMissionRecords class to execute SQL operations and
     * printDatabase results to the console.
     *
     * @param args command-line arguments supplied when the application starts
     */
    public static void main(String[] args) {

        // Create an instance of our database class, SoulMissionRecords.
        SoulMissionRecords db1 = new SoulMissionRecords();

        // Create a 2D arraylist to hold the result of a query (this can hold columns and rows of any type).
        ArrayList<ArrayList<Object>> data = new ArrayList<ArrayList<Object>>();

        // Perform a query to get all contents of the database.
        data = db1.getExecuteResult("select * from SoulMissionRecords;");

        // Print the result of the query, by printing what is stored in ArrayList data.
        for(List<Object> record : data){
            System.out.println(record.toString());
        }

        // Delete a row of data from the database, based on recordId.
        db1.delete("recordId","123456");
        System.out.println("Deleted.");

        //Printing the records again.
        data = db1.getExecuteResult("select * from SoulMissionRecords;");
        System.out.println("\n Here are the contents of the database: \n");
        printDatabse(data);

        // Add a new entry to the database.
        db1.insert(1234556, "Benijah", "Weapon", 72,
                0, 70.0,1,"2026-11-01");
        // Pull all records from the database and print.
        data = db1.getExecuteResult("select * from SoulMissionRecords;");
        System.out.println("\n Here are the contents of the database: \n");
        printDatabse(data);

    }

    /**
     * Displays the contents of the supplied database query results
     * by printing each record to the console. Iterates through the
     * ArrayList and converts each record into a readable String.
     *
     * @param data an ArrayList containing database records, with each
     * record represented by a List of Objects
     */
    public static void printDatabse(ArrayList<ArrayList<Object>> data){
        for (List<Object> record : data){
            System.out.println(record.toString());
        }
    }
}