/**
 * Be'Nijah Mitchell
 * CEN 3024-13038 - Software Development 1
 * November 7,2026
 */

package DBHelper;

import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
/**
 * Manages the SoulMissionRecords table in the SQLite database for the
 * DWMA Soul Mission Management System. This class extends DBHelper to
 * access database operations and provides functionality for inserting,
 * deleting, updating, retrieving, and displaying Soul Mission Records.
 * It also validates database column names and prepares SQL queries
 * used to interact with stored record information.
 */
public class SoulMissionRecords extends DBHelper {
	private final String TABLE_NAME = "SoulMissionRecords";
	public static final String recordId = "recordId";
	public static final String teamName = "teamName";
	public static final String partnerType = "partnerType";
	public static final String kishinSoulsCollected = "kishinSoulsCollected";
	public static final String witchSoulsCollected = "witchSoulsCollected";
	public static final String trainingLevel = "trainingLevel";
	public static final String activeStatus = "activeStatus";
	public static final String lastMissionDate = "lastMissionDate";

	/**
	 * Prepares a SQL SELECT statement using the specified fields,
	 * search criteria, and sorting options. Validates column names
	 * and sorting directions before constructing the query.
	 *
	 * @param fields the database columns to retrieve; null selects all columns
	 * @param whatField the database column used to search for a record
	 * @param whatValue the value being searched for in the specified column
	 * @param sortField the database column used to sort the results
	 * @param sort the sorting direction, either ASC or DESC
	 * @return a String containing the prepared SQL SELECT statement
	 * @throws IllegalArgumentException if an invalid search column,
	 * sorting column, or sorting direction is supplied
	 */
	private String prepareSQL(String fields, String whatField,
							  String whatValue, String sortField, String sort) {

		String query = "SELECT ";
		if (fields == null) {
			query += "*";
		} else {
			query += fields;
		}

		query += " FROM " + TABLE_NAME;
		if (whatField != null && whatValue != null) {
			if (!isValidColumn(whatField)) {
				throw new IllegalArgumentException("Invalid search column.");
			}

			query += " WHERE " + whatField + " = ?";
		}

		if (sort != null && sortField != null) {

			if (!isValidColumn(sortField)) {
				throw new IllegalArgumentException("Invalid sorting column.");
			}

			if (!sort.equalsIgnoreCase("ASC")
					&& !sort.equalsIgnoreCase("DESC")) {
				throw new IllegalArgumentException("Invalid sorting direction.");
			}

			query += " ORDER BY " + sortField + " " + sort.toUpperCase();
		}

		return query;
	}


	/**
	 * Inserts a new Soul Mission Record into the database using the
	 * supplied record information.
	 *
	 * @param recordId the unique ID assigned to the record
	 * @param teamName the name of the meister-and-weapon team
	 * @param partnerType the type of partner associated with the team
	 * @param kishinSoulsCollected the number of kishin-egg souls collected
	 * @param witchSoulsCollected the number of witch souls collected
	 * @param trainingLevel the team's current training level
	 * @param activeStatus the team's active status, represented as an integer
	 * @param lastMissionDate the date of the team's most recent mission
	 * @return true if the record was successfully inserted; otherwise, false
	 */
	public boolean insert(Integer recordId, String teamName, String partnerType,
						  Integer kishinSoulsCollected, Integer witchSoulsCollected,
						  Double trainingLevel, Integer activeStatus,
						  String lastMissionDate) {

		String sql = "INSERT INTO " + TABLE_NAME + " (recordId, teamName, partnerType, "
				+ "kishinSoulsCollected, witchSoulsCollected, " + "trainingLevel, activeStatus, lastMissionDate)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

		return super.executeUpdate(sql, recordId, teamName, partnerType,
				kishinSoulsCollected, witchSoulsCollected,
				trainingLevel, activeStatus, lastMissionDate) > 0;
	}


	/**
	 * Deletes a Soul Mission Record from the database using the specified
	 * column and value to identify the record.
	 *
	 * @param whatField the database column used to identify the record
	 * @param whatValue the value in the specified column used for deletion
	 * @return true if a record was successfully deleted; otherwise, false
	 */
	public boolean delete(String whatField, String whatValue) {
		if (!isValidColumn(whatField)) {
			System.out.println("Invalid database column.");
			return false;
		}

		String sql = "DELETE FROM " + TABLE_NAME + " WHERE " + whatField + " = ?";
		return super.executeUpdate(sql, whatValue) > 0;
	}

	/**
	 * Updates a specific database field for an existing Soul Mission Record.
	 * Identifies the record using the supplied search column and value.
	 *
	 * @param whatField the database column containing the information to update
	 * @param whatValue the new value to store in the specified column
	 * @param whereField the database column used to identify the record
	 * @param whereValue the value used to locate the record being updated
	 * @return true if the record was successfully updated; otherwise, false
	 */
	public boolean update(String whatField, String whatValue, String whereField, String whereValue) {

		if (!isValidColumn(whatField) || !isValidColumn(whereField)) {
			System.out.println("Invalid database column.");
			return false;
		}

		String sql = "UPDATE " + TABLE_NAME + " SET " + whatField + " = ?" + " WHERE " + whereField + " = ?";
		return super.executeUpdate(sql, whatValue, whereValue) > 0;
	}

	/**
	 * Updates all stored information for an existing Soul Mission Record.
	 * Uses the record ID to locate the record and replaces its remaining
	 * database values with the supplied information.
	 *
	 * @param recordId the ID of the record being updated
	 * @param teamName the updated name of the meister-and-weapon team
	 * @param partnerType the updated partner type
	 * @param kishinSoulsCollected the updated number of kishin-egg souls collected
	 * @param witchSoulsCollected the updated number of witch souls collected
	 * @param trainingLevel the updated team training level
	 * @param activeStatus the updated active status, represented as an integer
	 * @param lastMissionDate the updated date of the team's most recent mission
	 * @return true if the record was successfully updated; otherwise, false
	 */
	public boolean updateRecord(Integer recordId, String teamName, String partnerType, Integer kishinSoulsCollected,
								Integer witchSoulsCollected, Double trainingLevel, Integer activeStatus, String lastMissionDate) {

		String sql = "UPDATE " + TABLE_NAME + " SET teamName = ?, partnerType = ?, " +
				"kishinSoulsCollected = ?, witchSoulsCollected = ?, " + "trainingLevel = ?, activeStatus = ?, lastMissionDate = ? " +
				"WHERE recordId = ?";

		return super.executeUpdate(sql, teamName, partnerType, kishinSoulsCollected, witchSoulsCollected,
				trainingLevel, activeStatus, lastMissionDate, recordId) > 0;
	}

	/**
	 * Retrieves Soul Mission Record information from the database
	 * using the specified search and sorting criteria. Calls prepareSQL
	 * to construct the SELECT statement and executes the query through DBHelper.
	 *
	 * @param fields the database columns to retrieve; null selects all columns
	 * @param whatField the column used to search for a record
	 * @param whatValue the value being searched for in the specified column
	 * @param sortField the column used to sort the retrieved records
	 * @param sort the sorting direction, either ASC or DESC
	 * @return an ArrayList containing rows of database results, with each
	 * row represented by an ArrayList of Objects
	 * @throws IllegalArgumentException if invalid search or sorting
	 * criteria are supplied
	 */
	public ArrayList<ArrayList<Object>> select(String fields, String whatField, String whatValue, String sortField, String sort) {
		String sql = prepareSQL(fields, whatField, whatValue, sortField, sort);

		if (whatField != null && whatValue != null) {return super.executeQuery(sql, whatValue);}
		return super.executeQuery(sql);
	}


	/**
	 * Executes the supplied SQL query and retrieves the resulting
	 * database records.
	 *
	 * @param query the SQL statement to execute
	 * @return an ArrayList containing the query results, with each
	 * database row represented by an ArrayList of Objects
	 */
	public ArrayList<ArrayList<Object>> getExecuteResult(String query) {
		return super.executeQuery(query);
	}

	/**
	 * Executes the supplied SQL statement through the DBHelper class.
	 * This method is used to perform database commands that do not
	 * require the results to be returned to the calling method.
	 *
	 * @param query the SQL statement to execute
	 */
	public void execute(String query) {
		super.execute(query);
	}

	/**
	 * Checks whether the supplied column name matches one of the
	 * approved columns in the SoulMissionRecords database table.
	 * Prevents invalid column names from being used in SQL statements.
	 *
	 * @param column the database column name being checked
	 * @return true if the column is included in the approved column list;
	 * otherwise, false
	 */
	private boolean isValidColumn(String column) {

		return column != null && (
				column.equals(recordId)
						|| column.equals(teamName)
						|| column.equals(partnerType)
						|| column.equals(kishinSoulsCollected)
						|| column.equals(witchSoulsCollected)
						|| column.equals(trainingLevel)
						|| column.equals(activeStatus)
						|| column.equals(lastMissionDate)
		);
	}

	/**
	 * Retrieves database records and converts the query results into
	 * a DefaultTableModel for display in a JTable. Uses the supplied
	 * search and sorting criteria to prepare and execute the SQL query.
	 *
	 * @param fields the database columns to retrieve; null selects all columns
	 * @param whatField the column used to search for a record
	 * @param whatValue the value being searched for in the specified column
	 * @param sortField the column used to sort the retrieved records
	 * @param sort the sorting direction, either ASC or DESC
	 * @return a DefaultTableModel containing the retrieved database records
	 * @throws IllegalArgumentException if invalid search or sorting
	 * criteria are supplied
	 */
	public DefaultTableModel selectToTable(String fields, String whatField, String whatValue, String sortField, String sort) {
		String sql = prepareSQL(fields, whatField, whatValue, sortField, sort);

		if (whatField != null && whatValue != null) {
			return super.executeQueryToTable(sql, whatValue);
		}
		return super.executeQueryToTable(sql);
	}

}